# Name: Alika Bochkaryov
# Programming Language: Python
# File: client_chat1.py

from tkinter import *
from tkinter import ttk
import threading
import time
import socket
import tkinter.scrolledtext
import tkinter
from tkinter import messagebox
List_Of_Received_Messages = []

from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES


def Encrypt(key, message: str) -> bytes:
    """
    Encrypts a message using AES/GCM encryption, returns the encrypted message
    :param message: The message to encrypt
    :type message: str
    :return: The encrypted message
    """

    # Generate a random initialization vector (IV)
    iv = get_random_bytes(16)
    # Create a new AES-GCM cipher using the provided key and IV
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
    # Pad the plaintext to a multiple of 16 bytes
    plaintext_padded = pad(message.encode("UTF-8"), AES.block_size)
    # Encrypt the padded plaintext using the cipher and get the ciphertext and tag
    ciphertext, tag = cipher.encrypt_and_digest(plaintext_padded)

    # Return the IV, ciphertext, and tag as a single byte string
    return iv + ciphertext + tag


def Decrypt(key, ciphertext: bytes) -> str:
    """
    Decrypts a message using AES/GCM encryption, returns the decrypted message, if the tag is invalid, it will raise an exception.
    :param ciphertext: The message to decrypt
    :type ciphertext: bytes
    :return: The decrypted message
    """
    # AES-256/GCM
    # Extract the IV, ciphertext, and tag from the byte string
    iv, ciphertext, tag = ciphertext[:16], ciphertext[16:-16], ciphertext[-16:]
    # Create a new AES-GCM cipher using the provided key and IV
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
    # Decrypt the ciphertext using the cipher and verify the tag
    plaintext_padded = cipher.decrypt_and_verify(ciphertext, tag)
    # Unpad the plaintext to remove the padding bytes
    plaintext = unpad(plaintext_padded, AES.block_size).decode("UTF-8")

    # Return the plaintext as a byte string
    return plaintext


screen = ''
USER = ""
sucess = True
List_Of_Messages_To_Send = []
List_Of_Connected_Users = []
List_Of_Ip_Adresses = []
running = True
gui_done = False
text_area = ""
combo = ""
lst = []
index = 1
sum = 1
key = ""



def connect():
    """
    :param: nothing
    :return: nothing
    The function makes a connection between the server and the client
    and returns the connection between them.
    """
    global key
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(("127.0.0.1", 6555))
    key = client_socket.recv(1024)
    print(key)
    return client_socket


listofsenders = None
conn = connect()
gui = Tk()
frame = tkinter.Frame(gui, bg='#333333')
selected_sender = ""

def AddOption(combo, option):
    """
    :param combo:
    :param option:
    :return: nothing
    The function gets A scrolling list(ComboBox) and a username, then the function adds the username to the list.
    """
    combo['values'] += (option,)


def print_option(var, combo):
    """
    :param var:
    :param combo:
    :return: nothing
    The function prints the option that the client selected from the scrolling list, if nothing was selected the client
     will get an error message on the screen.
    """
    global selected_sender
    try:
        selected_sender = var.get()
        print(combo.get())
    except:
        messagebox.showinfo("Error", "You didn't select an option")


class GUI():
    client_socket = conn
    last_received_message = None

    def __init__(self, master):
        self.__root__ = master
        self.__chat_transcript_area__ = None
        self.__enter_text_widget__ = None
        self.__join_button__ = None
        self.__initialize_gui__()
        self.__listen_for_incoming_messages_in_thread__()

    def __initialize_gui__(self):
        self.__root__.title("Socket Chat")
        self.__root__.geometry("800x450")
        self.__root__.configure(bg='#333333')
        self.__display_name_section__()
        self.__display_chat_entry_box__()
        self.__display_chat_box__()

    def __listen_for_incoming_messages_in_thread__(self):
        thread = threading.Thread(target=self.__receive_message_from_server__)
        thread.start()



    def __receive_message_from_server__(self):
        global combo
        global lst
        global fernet
        global private_key
        global List_Of_Received_Messages
        global key
        while True:
                time.sleep(1)
                buffer = self.client_socket.recv(1024)
                print(buffer)
                #length_msg = self.client_socket.recv(1024)
                #length_msg = Decrypt(key, length_msg)
                #print("len_buffer = " + length_msg)
                #index = 0
                #correct_msg = ""
                #for i in buffer:
                 #   if index < int(length_msg):
                #        correct_msg += i
               #         index += 1
                try:
                  message = Decrypt(key, buffer)
                  print("decrypted = " + message)
                  if "*" in message:
                    splited = message.split("*")
                    for i in range(len(splited) - 1):
                        message = splited[i]
                        if message not in List_Of_Received_Messages:
                            List_Of_Received_Messages.append(message)
                        if "left" in message:
                            new_lst = []
                            for option in combo['values']:
                                if option != message.split(' left')[0]:
                                    new_lst.append(option)
                            combo['values'] = new_lst
                            self.__chat_transcript_area__.insert('end', str(message) + '\n')
                            self.__chat_transcript_area__.yview(END)
                        if "joined" in message:
                            user = message.split("joined:")[1]
                            msg = user + " has joined"
                            self.__chat_transcript_area__.insert('end', str(msg) + '\n')
                            self.__chat_transcript_area__.yview(END)
                            #for i in List_Of_Messages_To_Send:
                             #   self.client_socket.send(Encrypt(key, i))
                              #  time.sleep(1)
                        if "Add" in message:
                            option = message.split("Add:")[1]
                            if option not in lst:
                                AddOption(combo, option)
                                lst.append(option)
                  else:
                    if "<" in message and ">" in message:
                       self.__chat_transcript_area__.insert('end', str(message) + '\n')
                       self.__chat_transcript_area__.yview(END)
                except:
                    return 'break'
        self.client_socket.close()

    def __display_help_screen__(self):
        global USER
        new_window = Toplevel()
        tkinter.Label(master=new_window, text="Writing Private/Public Messages:" + "\n"
                                                                                   "1. Public Message - select All option and write your message" + "\n"
                                                                                                                                                    "2. Private Message - select one of the user options and then write your message" + "\n"
                                                                                                                                                                                                                                        "3. press ENTER button to send your message").pack(
            side='top')

    def __display_name_section__(self):
        global USER
        frame = Frame()
        if "LOGIN_FAILED" in USER:
            USER = USER.split("LOGIN_FAILED")[1]
        elif "LOGIN_OK" in USER:
            USER = USER.split("LOGIN_OK")[1]
        self.__on_join__()
        Label(frame, text="Hi " + USER, font=("arial", 13, "bold")).pack(side='left', padx=20, pady=20)
        self.__join_button__ = Button(frame, text="Help", width=10, command=self.__display_help_screen__). \
            pack(side='left', padx=20, pady=20)
        frame.pack(side='top', anchor='nw')

    def __display_chat_box__(self):
        global List_Of_Connected_Users
        global listofsenders
        global selected_sender
        global combo
        global lst
        frame = Frame()
        lst = ["all"]
        Label(frame, text="Chat Box", font=("arial", 12, "bold")).pack(side='top', padx=270)
        self.__chat_transcript_area__ = Text(frame, width=60, height=10, font=("arial", 12))
        scrollbar = Scrollbar(frame, command=self.__chat_transcript_area__.yview, orient=VERTICAL)
        var = tkinter.StringVar()
        combo = ttk.Combobox(frame, values=lst, textvariable=var)
        if USER not in lst:
            AddOption(combo, str(USER))
            lst.append(USER)
        combo.set("select an option")
        btn = tkinter.Button(frame, text="select the receivers", command=lambda: print_option(var, combo))
        self.__chat_transcript_area__.config(yscrollcommand=scrollbar.set)
        self.__chat_transcript_area__.bind('<KeyPress>', lambda e: 'break')
        self.__chat_transcript_area__.pack(side='left', padx=15, pady=10)
        scrollbar.pack(side='right', fill='y', padx=1)
        combo.pack()
        btn.pack()
        frame.pack(side='left')

    def __display_chat_entry_box__(self):
        frame = Frame()
        Label(frame, text='Enter your message here!', font=("arial", 12, "bold")).pack(side='top', anchor="w", padx=120)
        self.__enter_text_widget__ = Text(frame, width=50, height=10, font=("arial", 12))
        self.__enter_text_widget__.pack(side='left', pady=10, padx=10)
        self.__enter_text_widget__.bind('<Return>', self.__on_enter_key_pressed__)
        frame.pack(side='left')

    def __on_join__(self):
        global combo
        global lst
        global List_Of_Messages_To_Send
        #self.client_socket.send(Encrypt(key, str("joined:" + USER + "*")))
        #print("joined:" + USER + "*")
        #self.client_socket.send(Encrypt(key, str("Add:" + USER + "*")))
        #print("Add:" + USER + "*")
        self.client_socket.send(Encrypt(key, "Connected:" + USER + "*"))
        List_Of_Messages_To_Send.append(str("Add:" + USER + "*"))
        List_Of_Messages_To_Send.append(str("joined:" + USER + "*"))

    def __on_enter_key_pressed__(self, event):
        self.__send_chat__()
        self.__clear_text__()

    def __clear_text__(self):
        self.__enter_text_widget__.delete(1.0, 'end')

    def __send_chat__(self):
        global key
        global fernet
        global listofsenders
        global selected_sender
        senders_name = USER + ": "
        data = self.__enter_text_widget__.get(1.0, 'end').strip()
        if selected_sender == "":
            messagebox.showinfo("Error", "You didn't select an option")
        else:
            if len(data) < 100:
                message = (senders_name + "<" + selected_sender + ">" + str(data)).encode('utf-8')
                self.__chat_transcript_area__.insert('end', str(message) + "\n")
                self.__chat_transcript_area__.yview(END)
                self.client_socket.send(Encrypt(key, str(senders_name + "<" + selected_sender + ">" + data)))
                self.__enter_text_widget__.delete(1.0, 'end')
                return 'break'
            else:
                messagebox.showinfo("Error", "Couldn't send your message!")
                return 'break'

    def __on_close_window__(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.client_socket.send(Encrypt(key, "EXIT:" + str(USER)))
            self.__root__.destroy()
            self.client_socket.close()
            exit(0)


def open_chat():
    """
    :param: nothing
    :return: nothing
    The function opens a new gui screen and cals the GUI class.
    """
    global gui
    global conn
    gui.destroy()
    root = Tk()
    screen = GUI(root)
    root.protocol("WM_DELETE_WINDOW", screen.__on_close_window__)
    root.mainloop()


def open_chat_page():
    """
    :param: nothing
    :return: nothing
    The function changes the previous screen to a chat page screen.
    """
    global conn
    global frame
    global gui
    global USER
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("Chat")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    login_page_label = tkinter.Label(
        frame, text="CHATLY :)", bg='#333333', fg="pink", font=("Arial", 20))
    login_page_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
    user_label = tkinter.Label(
        frame, text="Hello " + str(USER) + ", what would you like to do? ", bg='#333333', fg="pink", font=("Arial", 16))
    user_label.grid(row=2, column=0, columnspan=2, sticky="news", pady=30)
    start_chating_button = tkinter.Button(
        frame, text="Start Chating", bg="pink", fg="black", font=("Arial", 16),
        command=open_chat)
    start_chating_button.grid(row=5, column=0, columnspan=2, pady=40)

    logout_page_button = tkinter.Button(
        frame, text="Logout", bg="pink", fg="black", font=("Arial", 16),
        command=open_indexpage)
    logout_page_button.grid(row=5, column=3, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def open_indexpage():
    """
    :param: nothing
    :return: nothing
    The function opens the main index page.
    """
    global gui
    global frame
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("index")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    path = "CHATLY LOGO.jpg"
    # Creates a Tkinter-compatible photo image, which can be used everywhere Tkinter expects an image object.
    img = PhotoImage(file=path)

    # Setting icon of master window
    gui.iconphoto(False, img)

    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    home_label = tkinter.Label(
        frame, text="Welcome to CHATLY!", bg='#333333', fg="pink", font=("Arial", 30))
    home_label.grid(row=0, column=2, columnspan=2, sticky="news", pady=40)
    text_label = tkinter.Label(
        frame,
        text="This chat is 4 everyone. I did this project as my" + "\n" + " final cyber project in school, and here you can login into your account" + "\n" + "or make a new one and start chatting with people that use CHATLY! Enjoyy :)",
        bg='#333333', fg="pink", font=("Arial", 16))
    text_label.grid(row=5, column=2, columnspan=2, sticky="news", pady=40)
    LOGIN_button = tkinter.Button(
        frame, text="Login", bg="pink", fg="black", font=("Arial", 16), command=Login_Page)

    # Placing widgets on the screen
    LOGIN_button.grid(row=15, column=1, columnspan=2, pady=30)
    signup_button = tkinter.Button(
        frame, text="Sign Up", bg="pink", fg="black", font=("Arial", 16),
        command=SignUp)
    # Placing widgets on the screen
    signup_button.grid(row=15, column=3, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def open_chat():
    """
    :param: nothing
    :return: nothing
    The function opens a new gui screen and cals the GUI class.
    """
    global gui
    global conn
    gui.destroy()
    root = Tk()
    screen = GUI(root)
    root.protocol("WM_DELETE_WINDOW", screen.__on_close_window__)
    root.mainloop()


def open_chat_page():
    """
    :param: nothing
    :return: nothing
    The function changes the previous screen to a chat page screen.
    """
    global conn
    global frame
    global gui
    global USER
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("Chat")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    login_page_label = tkinter.Label(
        frame, text="CHATLY :)", bg='#333333', fg="pink", font=("Arial", 20))
    login_page_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
    user_label = tkinter.Label(
        frame, text="Hello " + str(USER) + ", what would you like to do? ", bg='#333333', fg="pink", font=("Arial", 16))
    user_label.grid(row=2, column=0, columnspan=2, sticky="news", pady=30)
    start_chating_button = tkinter.Button(
        frame, text="Start Chating", bg="pink", fg="black", font=("Arial", 16),
        command=open_chat)
    start_chating_button.grid(row=5, column=0, columnspan=2, pady=40)

    logout_page_button = tkinter.Button(
        frame, text="Logout", bg="pink", fg="black", font=("Arial", 16),
        command=open_indexpage)
    logout_page_button.grid(row=5, column=3, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def open_indexpage():
    """
    :param: nothing
    :return: nothing
    The function opens the main index page.
    """
    global gui
    global frame
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("index")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    path = "CHATLY LOGO.jpg"
    # Creates a Tkinter-compatible photo image, which can be used everywhere Tkinter expects an image object.
    img = PhotoImage(file=path)

    # Setting icon of master window
    gui.iconphoto(False, img)

    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    home_label = tkinter.Label(
        frame, text="Welcome to CHATLY!", bg='#333333', fg="pink", font=("Arial", 30))
    home_label.grid(row=0, column=2, columnspan=2, sticky="news", pady=40)
    text_label = tkinter.Label(
        frame,
        text="This chat is 4 everyone. I did this project as my" + "\n" + " final cyber project in school, and here you can login into your account" + "\n" + "or make a new one and start chatting with people that use CHATLY! Enjoyy :)",
        bg='#333333', fg="pink", font=("Arial", 16))
    text_label.grid(row=5, column=2, columnspan=2, sticky="news", pady=40)
    LOGIN_button = tkinter.Button(
        frame, text="Login", bg="pink", fg="black", font=("Arial", 16), command=Login_Page)

    # Placing widgets on the screen
    LOGIN_button.grid(row=15, column=1, columnspan=2, pady=30)
    signup_button = tkinter.Button(
        frame, text="Sign Up", bg="pink", fg="black", font=("Arial", 16),
        command=SignUp)
    # Placing widgets on the screen
    signup_button.grid(row=15, column=3, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def Check_Forgot_Password(email, username):
    """
    :param email:
    :param username:
    :return: nothing
    The function sends the username and email to server and waits to get an "DATA_OK" and then the function opens the
     email validation page.
    """
    global index
    global conn
    global gui
    global frame
    data = "ForgotPassword:" + str(email) + "," + str(username)
    conn.send(Encrypt(key, data))
    answer = Decrypt(key, conn.recv(1024))
    if answer == "DATA_OK":
        messagebox.showinfo("Success", "Your data is correct!")
        response = Decrypt(key, conn.recv(1024))
        for widgets in frame.winfo_children():
            widgets.destroy()
        gui.title("New Password")
        gui.geometry("900x550")
        gui.configure(bg='#333333')
        vali_label = tkinter.Label(
            frame, text="Validation of email", bg='#333333', fg="pink", font=("Arial", 30))
        vali_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
        # set the title of the Window
        code_label = tkinter.Label(
            frame, text="Please Enter The Code You Received In Your Email: ", bg='#333333', fg="#FFFFFF",
            font=("Arial", 16))
        code_entry = tkinter.Entry(frame, font=("Arial", 16))
        code_label.grid(row=1, column=0)
        code_entry.grid(row=1, column=1, pady=20)
        # place of the title
        number = 0
        index = 1
        login1_button = tkinter.Button(
            frame, text="Enter", bg="pink", fg="black", font=("Arial", 16),
            command=lambda: validation_of_email(response, code_entry, number + index))

        # Placing widgets on the screen
        login1_button.grid(row=4, column=0, columnspan=2, pady=30)
        frame.pack()
        gui.mainloop()
    else:
        messagebox.showinfo("Error", "The email doesn't match the username you have entered!")
        open_indexpage()


def validation_of_email(response, code_entry, number):
    """
    :param: response
    :param: code_entry
    :param: number
    :return: nothing
    The function checks if the code that the client entered in the validation entry is correct.
    """
    global index
    global gui
    global frame
    if number < 4:
        if response == code_entry.get():
            messagebox.showinfo("Success", "You have entered the correct code!")
            for widgets in frame.winfo_children():
                widgets.destroy()
            gui.title("Reset Password Page")
            gui.geometry("1000x650")
            gui.configure(bg='#333333')
            home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
            home_button.place(x=850, y=10)
            login_page_label = tkinter.Label(
                frame, text="Reset Page", bg='#333333', fg="pink", font=("Arial", 30))
            username_page_label = tkinter.Label(
                frame, text="Username", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
            username_page_entry = tkinter.Entry(frame, font=("Arial", 16))
            password_page_label = tkinter.Label(
                frame, text="Reset Password", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
            password_page_entry = tkinter.Entry(frame, font=("Arial", 16))
            login_page_button = tkinter.Button(
                frame, text="Reset", bg="pink", fg="black", font=("Arial", 16),
                command=lambda: check_Reset_Page(username_page_entry.get(), password_page_entry.get()))
            # Placing widgets on the screen
            login_page_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
            username_page_label.grid(row=2, column=0)
            username_page_entry.grid(row=2, column=1, pady=20)
            password_page_label.grid(row=3, column=0)
            password_page_entry.grid(row=3, column=1, pady=20)
            login_page_button.grid(row=4, column=0, columnspan=2, pady=30)
            frame.pack()
            gui.mainloop()
        else:
            messagebox.showinfo("Error", "The code you have entered is wrong")
            index += 1
    else:
        messagebox.showinfo("Error", "You have tried too many times!")
        open_indexpage()


def Forgot_Password():
    """
    :param: nothing
    :return: nothing
    The function opens the the reset/forgot password page.
    """
    global gui
    global frame
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("Forgot Password Page")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    login_page_label = tkinter.Label(
        frame, text="Forgot Password", bg='#333333', fg="pink", font=("Arial", 30))
    username_page_label = tkinter.Label(
        frame, text="Username", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    username_page_entry = tkinter.Entry(frame, font=("Arial", 16))
    email_page_label = tkinter.Label(
        frame, text="Email", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    email_page_entry = tkinter.Entry(frame, font=("Arial", 16))
    login_page_button = tkinter.Button(
        frame, text="Next", bg="pink", fg="black", font=("Arial", 16),
        command=lambda: Check_Forgot_Password(email_page_entry.get(), username_page_entry.get()))
    # Placing widgets on the screen
    login_page_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
    username_page_label.grid(row=2, column=0)
    username_page_entry.grid(row=2, column=1, pady=20)
    email_page_label.grid(row=3, column=0)
    email_page_entry.grid(row=3, column=1, pady=20)
    login_page_button.grid(row=4, column=0, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def Login_Page():
    """
    :param: nothing
    :return: nothing
    The function opens the login page and takes care of it.
    """
    global frame
    global gui
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("Login Page")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')
    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    login_page_label = tkinter.Label(
        frame, text="Login", bg='#333333', fg="pink", font=("Arial", 30))
    username_page_label = tkinter.Label(
        frame, text="Username", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    username_page_entry = tkinter.Entry(frame, font=("Arial", 16))
    password_page_label = tkinter.Label(
        frame, text="Password", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    password_page_entry = tkinter.Entry(frame, font=("Arial", 16))
    login_page_button = tkinter.Button(
        frame, text="Login", bg="pink", fg="black", font=("Arial", 16),
        command=lambda: check_Login_Page(username_page_entry.get(), password_page_entry.get()))
    forgot_password_page_button = tkinter.Button(
        frame, text="Forgot Password", bg="pink", fg="black", font=("Arial", 16),
        command=Forgot_Password)
    # Placing widgets on the screen
    login_page_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
    username_page_label.grid(row=2, column=0)
    username_page_entry.grid(row=2, column=1, pady=20)
    password_page_label.grid(row=3, column=0)
    password_page_entry.grid(row=3, column=1, pady=20)
    login_page_button.grid(row=4, column=0, columnspan=2, pady=30)
    forgot_password_page_button.grid(row=5, column=0, columnspan=2, pady=30)
    frame.pack()
    gui.mainloop()


def check_Reset_Page(username, password):
    """
    :param username:
    :param password:
    :return: nothing
    The function checks if the reset was successful and the data of what the client was correct.
    """
    global gui
    global conn
    global USER
    print("Sending login message to server......")

    def function_username(username):
        """
        :param username:
        :return: nothing
        The function checks if the username does not contain forbidden letters.
        """
        error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                      ":",
                      ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                      "צ", "ק", "ר", "ש",
                      "ת", "ך", "ץ", "א"]
        for i in range(len(username)):
            for e in error_list:
                if e == username[i]:
                    messagebox.showinfo("Error", "Invalid username!")
                    return False
        return True

    def function_password(login_password):
        """
        :param login_password:
        :return: nothing
        The function checks if the password does not contain forbidden letters.
        """
        error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                      ":",
                      ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                      "צ", "ק", "ר", "ש",
                      "ת", "ך", "ץ", "א"]
        if len(login_password) < 1:
            messagebox.showinfo("Error", "Invalid password!")
            return False
        for i in range(len(login_password)):
            for e in error_list:
                if e == login_password[i]:
                    messagebox.showinfo("Error", "Invalid password!")
                    return False
        return True

    global List_Of_Connected_Users
    check1 = function_username(username)
    check2 = function_password(password)
    if check1 == True and check2 == True:
        conn.send(Encrypt(key, "RESET:" + str(username) + "*" + str(password)))
        print("message was sent")
        print(("RESET:" + str(username) + "*" + str(password)))
        msg = Decrypt(key, conn.recv(1024))
        print("Got an answer from server....")
        print(msg)
        if "RESET_OK" in msg:
            messagebox.showinfo("Success", "Reset completed!")
            USER = Decrypt(key, conn.recv(1024))
            if "RESET_OK" in USER:
                USER = USER.split("RESET_OK")[1]
            open_chat_page()
        elif "RESET_FAILED" in msg:
            messagebox.showinfo("Error", "Reset failed!")
            open_indexpage()
    else:
        messagebox.showinfo("Error", "You used forbidden letters and symbols. Please try again!")
        Login_Page()


def check_Login_Page(username, password):
    """
    :param username:
    :param password:
    :return: nothing
    The function checks the information in the login page and send a suitable message to the client.
    """
    global gui
    global conn
    global USER
    print("Sending login message to server......")

    def function_username(username):
        """
        :param username:
        :return: nothing
        The function checks if the username was written correctly by the client.
        """
        error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                      ":",
                      ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                      "צ", "ק", "ר", "ש",
                      "ת", "ך", "ץ", "א"]
        for i in range(len(username)):
            for e in error_list:
                if e == username[i]:
                    return False
        return True

    def function_password(login_password):
        """
        :param login_password:
        :return: nothing
        The function checks if the password was written correctly by the client.
        """
        error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                      ":",
                      ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                      "צ", "ק", "ר", "ש",
                      "ת", "ך", "ץ", "א"]
        if len(login_password) < 1:
            return False
        for i in range(len(login_password)):
            for e in error_list:
                if e == login_password[i]:
                    return False
        return True

    global List_Of_Connected_Users
    check1 = function_username(username)
    check2 = function_password(password)
    if check1 == True and check2 == True:
        if username in List_Of_Connected_Users:
            messagebox.showinfo("Error", "The user already connected!")
            Login_Page()
        conn.send(Encrypt(key, ("LOGIN:" + str(username) + "*" + password)))
        print("message was sent")
        print(("LOGIN:" + str(username) + "*" + password))
        msg = Decrypt(key, conn.recv(1024))
        print("Got an answer from server....")
        print(msg)
        if "LOGIN_OK" in msg:
            List_Of_Connected_Users.append(username)
            messagebox.showinfo("Success", "Login completed!")
            USER = username
            if "LOGIN_OK" in USER:
                USER = USER.split("LOGIN_OK")[1]
            open_chat_page()
        elif "LOGIN_FAILED" in msg:
            messagebox.showinfo("Error", "Login failed!")
            Login_Page()
    else:
        messagebox.showinfo("Error", "Login failed!")
        Login_Page()


def SignUp():
    """
    :param: nothing
    :return: nothing
    The main Login function is making the login form with the second login function that makes sure
    the client is connected and his username and password are correct.
    """
    global gui
    import tkinter
    global frame
    from tkinter import messagebox
    global sucess
    sucess = True
    for widgets in frame.winfo_children():
        widgets.destroy()
    gui.title("SignUp form")
    gui.geometry("1000x650")
    gui.configure(bg='#333333')

    def signup():
        global sum
        """
        :param: nothing
        :return: nothing
        The function takes the username and th password that the client wrote and sends the server a LOGIN
        message and waits for a response, if the response is positive the clients is logged in and can
        start the trivia quiz, else the client needs to try to log in again.
        """
        global USER
        check = True

        def phone():
            """
            :param: nothing
            :return: nothing
            The function checks if the phone number that the user filled out was written correctly.
            """
            global sucess
            check = True
            client_phone = phone_entry.get()
            for i in range(len(client_phone)):
                if client_phone[i] != "0" and client_phone[i] != "1" and client_phone[i] != "2" and client_phone[
                    i] != "3" and \
                        client_phone[i] != "4" and client_phone[i] != "5" and client_phone[i] != "6" and client_phone[
                    i] != "7" and client_phone[i] != "8" and client_phone[i] != "9":
                    check = False
            if check == False or len(client_phone) != 10:
                if sucess == True:
                    sucess = False

        def username_and_password(username):
            """
            :param username:
            :return: nothing
            The function checks if the username/password was written correctly.
            """
            global sucess
            error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                          ":",
                          ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                          "צ", "ק", "ר", "ש",
                          "ת", "ך", "ץ", "א"]
            for i in range(len(username)):
                for e in error_list:
                    if e == username[i]:
                        if sucess == True:
                            sucess = False

        def full_name(fullname):
            """
            :param fullname:
            :return: nothing
            The function checks if the fullname does not contain forbidden letters.
            """
            global sucess
            error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                          ":",
                          ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                          "צ", "ק", "ר", "ש",
                          "ת", "ך", "ץ", "א", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
            for i in range(len(fullname)):
                for e in error_list:
                    if e == fullname[i]:
                        if sucess == True:
                            sucess = False

        def validation(response, code_entry, number, username):
            """
            :param response:
            :param code_entry:
            :param number:
            :param username:
            :return: nothing
            The function checks if the code that the client entered match the code that was sent to the clients mail.
            """
            global conn
            global sum
            global USER
            if number < 4:
                if response == code_entry.get():
                    messagebox.showinfo("Success", "Your are saved in the system!")
                    conn.send("success".encode())
                    USER = username
                    open_chat_page()
                else:
                    messagebox.showinfo("Error", "The code you have entered is wrong")
                    sum += 1
            else:
                messagebox.showinfo("Error", "You have tried too many times!")
                open_indexpage()

        def email():
            """
            :param: nothing
            :return: nothing
            The function checks if the email was written correctly.
            """
            global sucess
            shtrudel = False
            point = False
            error = False
            client_email = email_entry.get()
            error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                          ":",
                          ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                          "צ", "ק", "ר", "ש",
                          "ת", "ך", "ץ", "א"]
            for i in range(len(client_email)):
                for e in error_list:
                    if e == client_email[i]:
                        error = True
                        if sucess == True:
                            sucess = False
            for i in range(len(client_email)):
                if client_email[i] == "@":
                    shtrudel = True
                elif client_email[i] == ".":
                    point = True
            if shtrudel == False or point == False or error == True:
                if sucess == True:
                    sucess == False

        username = username_entry.get()
        full_name(fullname_entry.get())
        username_and_password(username)
        username_and_password(password_entry.get())
        email()
        phone()
        if username in List_Of_Connected_Users:
            messagebox.showinfo("Error", "The user is already connected!")
            SignUp()
        conn.send(Encrypt(key, ("SIGNUP:" + str(fullname_entry.get()) + "*" + str(username_entry.get()) + "*" + str(password_entry.get()) +
             "*" + str(email_entry.get()) + "*" + str(phone_entry.get()))))
        answer = Decrypt(key, conn.recv(1024))
        if answer == "SIGNUP_OK":
            response = Decrypt(key, conn.recv(1024))
            messagebox.showinfo("SignUp Success", "You successfully SignUp!")
            for widgets in frame.winfo_children():
                widgets.destroy()
            number_of_tries = 0
            gui.title("Validation")
            gui.geometry("900x550")
            gui.configure(bg='#333333')
            vali_label = tkinter.Label(
                frame, text="Validation", bg='#333333', fg="pink", font=("Arial", 30))
            vali_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
            # set the title of the Window
            code_label = tkinter.Label(
                frame, text="Please Enter Code: ", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
            code_entry = tkinter.Entry(frame, font=("Arial", 16))
            code_label.grid(row=1, column=0)
            code_entry.grid(row=1, column=1, pady=20)
            # place of the title
            sum = 1
            login1_button = tkinter.Button(
                frame, text="Enter", bg="pink", fg="black", font=("Arial", 16),
                command=lambda: validation(response, code_entry, number_of_tries + sum, username))
            # Placing widgets on the screen
            login1_button.grid(row=4, column=0, columnspan=2, pady=30)
            frame.pack()
            gui.mainloop()
            open_chat_page()
        elif answer == "The user already exists!":
            messagebox.showinfo("SignUp Failed", "The user already exists!")
        elif answer == "Email already exists!":
            messagebox.showinfo("SignUp Failed", "Email already exists!")
        else:
            messagebox.showinfo("Error", "SignUp Failed!")

    # Creating widgets
    home_button = tkinter.Button(gui, text="HOME", command=open_indexpage)
    home_button.place(x=850, y=10)
    login_label = tkinter.Label(
        frame, text="SignUp", bg='#333333', fg="pink", font=("Arial", 30))
    email_label = tkinter.Label(
        frame, text="Email", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    phone_label = tkinter.Label(
        frame, text="PhoneNumber", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    username_label = tkinter.Label(
        frame, text="Username", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    fullname_label = tkinter.Label(
        frame, text="FullName", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    fullname_entry = tkinter.Entry(frame, font=("Arial", 16))
    username_entry = tkinter.Entry(frame, font=("Arial", 16))
    email_entry = tkinter.Entry(frame, font=("Arial", 16))
    phone_entry = tkinter.Entry(frame, font=("Arial", 16))
    password_entry = tkinter.Entry(frame, show="*", font=("Arial", 16))
    password_label = tkinter.Label(
        frame, text="Password", bg='#333333', fg="#FFFFFF", font=("Arial", 16))
    login_button = tkinter.Button(
        frame, text="SignUp", bg="pink", fg="black", font=("Arial", 16), command=signup)
    # Placing widgets on the screen
    login_label.grid(row=0, column=0, columnspan=2, sticky="news", pady=40)
    fullname_label.grid(row=1, column=0)
    fullname_entry.grid(row=1, column=1, pady=20)
    username_label.grid(row=2, column=0)
    username_entry.grid(row=2, column=1, pady=20)
    password_label.grid(row=3, column=0)
    password_entry.grid(row=3, column=1, pady=20)
    email_label.grid(row=4, column=0)
    email_entry.grid(row=4, column=1, pady=20)
    phone_label.grid(row=5, column=0)
    phone_entry.grid(row=5, column=1, pady=20)
    login_button.grid(row=6, column=0, columnspan=2, pady=30)
    frame.pack()

    gui.mainloop()


open_indexpage()
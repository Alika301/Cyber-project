import sqlite3


class Users:
    """Creates database with users table includes:
       create query
       insert query
       select query
    """

    def __init__(self, tablename="users", userId="userId", password="password", username="username", fullname="fullname", email="email", phone="phone"):
        self.__tablename = tablename
        self.__userId = userId
        self.__password = password
        self.__username = username
        self.__fullname = fullname
        self.__email = email
        self.__phone = phone
        conn = sqlite3.connect('test.db')
        print("Opened database successfully")
        query_str = "CREATE TABLE IF NOT EXISTS " + tablename + "(" + self.__userId + " " + \
                    "INTEGER PRIMARY KEY AUTOINCREMENT,"
        query_str += " " + self.__password + " TEXT   NOT NULL,"
        query_str += " " + self.__username + " TEXT    NOT NULL,"
        query_str += " " + self.__fullname + " TEXT    NOT NULL,"
        query_str += " " + self.__email + " TEXT    NOT NULL,"
        query_str += " " + self.__phone + " TEXT    NOT NULL);"
        #conn.execute("drop table users")
        conn.execute(query_str)
        print("Table created successfully")
        conn.commit()
        conn.close()

    def __str__(self):
        return "table  name is ", self.__tablename

    def get_table_name(self):
        return self.__tablename

    def insert_user(self, username, password, fullname, email, phone):
        conn = sqlite3.connect('test.db')
        user = self.get_only_user_by_username(username)
        if user != username:
            insert_query = "INSERT INTO " + self.__tablename + " (" + self.__username + "," + self.__password + "," + self.__fullname + "," + self.__email + "," + self.__phone + ") VALUES " \
                                                                                                            "(" + "'" + username + "'" + "," + "'" + password + "'" + "," + "'" + fullname + "'" + "," + "'" + email + "'" + "," + "'" + phone + "'" + ");"
            print(insert_query)
            conn.execute(insert_query)
            conn.commit()
            conn.close()
            print("Record created successfully")
        else:
            print("username already exists so the user wasn't added")

    def get_user_by_username(self, username):
        conn = sqlite3.connect('test.db')
        strsql = "SELECT username, password  from " + self.__tablename + " where " + self.__username + "=" + "\"" + str(username) + "\""

        print(strsql)
        cursor = conn.execute(strsql)
        result = cursor.fetchall()
        length = (len(result))
        print(length)
        if length == 0:
            return "NO_USERNAME", "NO_PASSWORD"
        else:
            for row in result:
                print("username = ", row[0])
                print("password = ", row[1])
                return row[0], row[1]
    def get_email_by_username(self, username):
        conn = sqlite3.connect('test.db')
        strsql = "SELECT email  from " + self.__tablename + " where " + self.__username + "=" \
                 + "\"" + str(username) + "\""

        print(strsql)
        cursor = conn.execute(strsql)
        for row in cursor:
            print("email = ", row[0])
            if row[0] == None:
                return "NO_USERNAME"
            else:
                return row[0]
    def set_password(self, username, password):
        conn = sqlite3.connect('test.db')
        strsql = "UPDATE " + self.__tablename + " SET password =" + "\"" + str(password) + "\"" + " where " + self.__username + "=" \
                 + "\"" + str(username) + "\""

        print(strsql)
        cursor = conn.execute(strsql)
        conn.commit()
        cursor.close()
    def get_only_user_by_username(self, username):
        conn = sqlite3.connect('test.db')
        strsql = "SELECT username  from " + self.__tablename + " where " + self.__username + "=" \
                 + "\"" + str(username) + "\""

        print(strsql)
        cursor = conn.execute(strsql)
        for row in cursor:
            print("username = ", row[0])
            if row[0] == None:
                return "NO_USERNAME"
            else:
                return row[0]
    def get_all_usernames_from_database(self):
        conn = sqlite3.connect('test.db')
        strsql = "SELECT username  from " + self.__tablename + " * "

        print(strsql)
        cursor = conn.execute(strsql)
        return cursor


    def select_user_by_id(self, userId):
        conn = sqlite3.connect('test.db')
        print("Opened database successfully")
        str1 = "select * from users;"

        strsql = "SELECT userId, username, password, fullname, email, phone  from " + self.__tablename + " where " + self.__userId + "=" \
            + str(userId)

        print(strsql)
        cursor = conn.execute(strsql)
        for row in cursor:
            print("userId = ", row[0])
            print("username = ", row[1])
            print("password = ", row[2])
            print("fullname = ", row[3])
            print("email = ", row[4])
            print("phone = ", row[5])
        print("Operation done successfully")
        conn.close()

from Crypto.Cipher import AES
from base64 import b64encode, b64decode
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes


import hashlib

def hash_data(data):
        hash_object = hashlib.sha256(
            data.encode())  # Use sha256 algorithm (you can choose a different algorithm if desired)
        hashed_data = hash_object.hexdigest()  # Get the hexadecimal representation of the hash
        return hashed_data

hash = str(hash_data("test"))

u = Users()
u.insert_user("test", hash, "test", "test@gmail.com", "2345678901")



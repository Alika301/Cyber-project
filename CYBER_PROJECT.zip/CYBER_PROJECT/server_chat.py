# Name: Alika Bochkaryov
# Programming Language: Python
# File: server_chat.py

import socket
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES
import hashlib
import threading
import sqlite_db
import time
from email.message import EmailMessage
import random
import ssl
import smtplib
List_Of_Chat_Messages = []
connected_sockets = []
conn_index = 0
connected_users = []
table = sqlite_db.Users()
sucess = True
clients = []


def Encrypt(key, message: str) -> bytes:
    """
    Encrypts a message using AES/GCM encryption, returns the encrypted message
    :param message: The message to encrypt
    :type message: str
    :return: The encrypted message
    """

    # Generate a random initialization vector (IV)
    iv = get_random_bytes(16)
    # Create a new AES-GCM cipher using the provided key and IV
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
    # Pad the plaintext to a multiple of 16 bytes
    plaintext_padded = pad(message.encode("UTF-8"), AES.block_size)
    # Encrypt the padded plaintext using the cipher and get the ciphertext and tag
    ciphertext, tag = cipher.encrypt_and_digest(plaintext_padded)

    # Return the IV, ciphertext, and tag as a single byte string
    return iv + ciphertext + tag


def Decrypt(key, ciphertext: bytes) -> str:
    """
    Decrypts a message using AES/GCM encryption, returns the decrypted message, if the tag is invalid, it will raise an exception.
    :param ciphertext: The message to decrypt
    :type ciphertext: bytes
    :return: The decrypted message
    """
    # AES-256/GCM
    # Extract the IV, ciphertext, and tag from the byte string
    iv, ciphertext, tag = ciphertext[:16], ciphertext[16:-16], ciphertext[-16:]
    # Create a new AES-GCM cipher using the provided key and IV
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
    # Decrypt the ciphertext using the cipher and verify the tag
    plaintext_padded = cipher.decrypt_and_verify(ciphertext, tag)
    # Unpad the plaintext to remove the padding bytes
    plaintext = unpad(plaintext_padded, AES.block_size).decode("UTF-8")

    # Return the plaintext as a byte string
    return plaintext


key = get_random_bytes(16)
print(key)

def hash_data(data):
    hash_object = hashlib.sha256(
        data.encode())  # Use sha256 algorithm (you can choose a different algorithm if desired)
    hashed_data = hash_object.hexdigest()  # Get the hexadecimal representation of the hash
    print("hashed_data = " + hashed_data)
    return hashed_data

def check_username_and_password(username):
    """
    :param: username
    :return: nothing
    The function checks if the username and password does not contain forbidden letters or sihns.
    """
    global sucess
    error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=", ":",
                  ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ",
                  "ק", "ר", "ש",
                  "ת", "ך", "ץ", "א"]
    for i in range(len(username)):
        for e in error_list:
            if e == username[i]:
                if sucess == True:
                    sucess = False

def check_email(email):
    """
    :param: email
    :return: nothing
    The function checks if the email is written correct.
    """
    global sucess
    shtrudel = False
    point = False
    error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=", ":",
                  ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ", "ק", "ר", "ש",
                  "ת", "ך", "ץ", "א"]
    for i in range(len(email)):
        if email[i] == ".":
            point = True
        elif email[i] == "@":
            shtrudel = True
        for e in error_list:
            if e == email[i]:
                if sucess == True:
                    sucess = False
    if point == False or shtrudel == False:
        if sucess == True:
            sucess = False

def check_full_name(fullname):
    """
    :param: fullname:
    :return: nothing
    The function checks if the fullname does not contain forbidden letters.
    """
    error_list = [")", "(", "*", "&", "^", "%", "$", "#", "!", "|", "/", "{", "}", "]", "[", "-", "_", "+", "=",
                      ":",
                      ";", ">", "<", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ",
                      "צ", "ק", "ר", "ש",
                      "ת", "ך", "ץ", "א", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
    for i in range(len(fullname)):
        for e in error_list:
            if e == fullname[i]:
                if sucess == True:
                    sucess = False

def check_phone(phone):
    """
    :param: phone
    :return: nothing
    The function checks if the phone number is written correctly.
    """
    global sucess
    check = True
    for i in range(len(phone)):
        if phone[i] != "0" and phone[i] != "1" and phone[i] != "2" and phone[
            i] != "3" and \
                phone[i] != "4" and phone[i] != "5" and phone[i] != "6" and phone[
            i] != "7" and phone[i] != "8" and phone[i] != "9":
            check = False
    if check == False or len(phone) != 10:
        if sucess == True:
            sucess = False


def Login(current, data):
    """
    :param: current
    :param: data
    :return: nothing
    The function gets a socket and the data which contains username and password and the function checks if they exists in the database.
    """
    global sucess
    global connected_users
    global connected_sockets
    global conn_index
    list = data.split("*")
    print("Got the login message from client")
    username = list[0]
    password = list[1]
    check_username_and_password(username)
    check_username_and_password(password)
    real_username, real_password = table.get_user_by_username(username)
    if sucess == True:
        print("Sending an answer...")
        if real_username == username and real_password == str(hash_data(password)) and username not in connected_users:
            current.send(Encrypt(key, "LOGIN_OK"))
            print("LOGIN_0K")
            connected_users.append(username)
            connected_sockets.append(current)
        elif real_username == "NO_USERNAME" and real_password == "NO_PASSWORD":
            current.send(Encrypt(key, "LOGIN_FAILED"))
            print("You are not registered on this application")
        else:
            current.send(Encrypt(key, "LOGIN_FAILED"))
    else:
        current.send(Encrypt(key, "LOGIN_FAILED"))
        print("LOGIN_FAILED")






def SignUp(current, data):
    """
    :param: current
    :param: data
    This function gets a socket and data from the client that contains the username
    and the password that the client wrote, if they ate correct the server sends a
    positive message so the client can connect, if they are not correct the server sends
    a negative message that doesn't give the client permission to connect.
    """
    global sucess
    list = data.split("*")
    fullname = list[0]
    username = list[1]
    password = list[2]
    email = list[3]
    phone = list[4]
    boo = False
    count = 0
    check_full_name(fullname)
    check_username_and_password(username)
    check_username_and_password(password)
    check_email(email)
    check_phone(phone)
    real_username = table.get_only_user_by_username(username)
    print(real_username)
    if real_username == username and count == 0:
        current.send(Encrypt(key, "The user already exists!"))
        count = 1
    elif sucess == True and count == 0 and real_username == None:
        current.send(Encrypt(key, "SIGNUP_OK"))
        email_receiver = email
        email_sender = "alikabo301@gmail.com"
        email_password = "lmfo mwfd eyky uxku"
        subject = "Validation Code"
        code = random.randint(1000, 9999)
        body = "code - " + str(code)
        new_email = EmailMessage()
        new_email['From'] = email_sender
        new_email['To'] = email_receiver
        new_email['Subject'] = subject
        new_email.set_content(body)
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as smtp:
            smtp.login(email_sender, email_password)
            smtp.sendmail(email_sender, email_receiver, new_email.as_string())
        current.send(Encrypt(key, str(code)))
        print(str(code))
        if Decrypt(key, current.recv(1024)) == "success":
            table.insert_user(username, str(hash_data(password)), fullname, email, phone)
            print("added client")
            boo = True
            count = 1
            connected_users.append(username)
            connected_sockets.append(current)

    elif boo == False and count == 0:
        current.send(Encrypt(key, "SIGNUP_FAILED"))
        count = 1

def forgot_password(data, client):
        """
        :param: data
        :param: client
        :return: nothing
        The function checks if the username and email exists and match in the database.
        """
        global sqlite_db
        print(data)
        email, username = data.split(",")
        real_user = table.get_only_user_by_username(username)
        print("real_user= " + real_user)
        real_email = table.get_email_by_username(username)
        print("real_email= " + real_email)
        if email == real_email and username == real_user:
            client.send(Encrypt(key, "DATA_OK"))
            print("DATA_OK")
            email_receiver = real_email
            email_sender = "alikabo301@gmail.com"
            email_password = "lmfo mwfd eyky uxku"
            subject = "Validation Code"
            code = random.randint(1000, 9999)
            body = "code - " + str(code)
            new_email = EmailMessage()
            new_email['From'] = email_sender
            new_email['To'] = email_receiver
            new_email['Subject'] = subject
            new_email.set_content(body)
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as smtp:
                smtp.login(email_sender, email_password)
                smtp.sendmail(email_sender, email_receiver, new_email.as_string())
            client.send(Encrypt(key, str(code)))
            print(str(code))
            boo = True
            count = 1
        else:
            client.send(Encrypt(key, "DATA_WRONG"))
            print("DATA_WRONG")


def Reset_Password(data, client):
    """
    :param: data
    :param: client
    :return: nothing
    The function changes the password in the database that matches the username.
    """
    global sqlite_db
    username, new_password = data.split("*")
    real_user = table.get_only_user_by_username(username)
    if real_user == username:
        table.set_password(username, str(hash_data(new_password)))
        user, check_new_pass = table.get_user_by_username(username)
        print("new_password? = " + check_new_pass)
        if check_new_pass == str(hash_data(new_password)):
            print("RESET_OK")
            client.send(Encrypt(key, "RESET_OK"))
            client.send(Encrypt(key, str(real_user)))
        else:
            print("RESET_FAILED")
            client.send(Encrypt(key, "RESET_FAILED"))
    else:
        print("RESET_FAILED")
        client.send(Encrypt(key, "RESET_FAILED"))


client_list = []
last_received_messages = ""
Msg_Lst = []
user = ""

def receive_messages(client):
        """
        :param: client
        :return: nothing
        The function gets the client socket and waits for a message from the client and the function calls the specific
        function to answer the client's request.
        """
        global key
        global user
        global last_received_messages
        global client_list
        global connected_sockets
        global connected_users
        global List_Of_Chat_Messages
        global Msg_Lst
        while True:
            while True:
                     incoming_buffer = client.recv(1024)
                     last_received_messages = Decrypt(key, incoming_buffer)
                     print("msg = " + last_received_messages)
                     cmd, data = last_received_messages.split(":")
                     if cmd == "SIGNUP":
                        SignUp(client, data)
                     if cmd == "RESET":
                        Reset_Password(data, client)
                     if cmd == "LOGIN":
                        print("Starts the login function....")
                        Login(client, data)
                     if cmd == "Connected":
                         Msg_Lst.append("Add:" + data)
                         Msg_Lst.append("joined:" + data)
                         if len(Msg_Lst) > 2:
                                for j in range(int(len(Msg_Lst)/2)):
                                    for i in Msg_Lst:
                                        client_list[j].send(Encrypt(key, str(i)))
                                        time.sleep(1)
                     if cmd == "Add":
                         brodcast_to_all_clients(client, Encrypt(key, "Add:" + data + "*"))
                     if cmd == "ForgotPassword":
                        print("starting the forgot password function")
                        forgot_password(data, client)
                     if cmd == "joined":
                          joined_msg = incoming_buffer
                          print(incoming_buffer)
                          print("joined")
                          joined_user = data
                          brodcast_to_all_clients_encrypted(client, joined_msg)
                          #time.sleep(1)
                          #send_Add_msg(joined_user)
                          if last_received_messages not in List_Of_Chat_Messages:
                            List_Of_Chat_Messages.append(last_received_messages)
                            List_Of_Chat_Messages.append("Add:" + joined_user + "*")
                          #for i in List_Of_Chat_Messages:
                               #client.send(Encrypt(key, str(i)))
                            #  client.send(Encrypt(key, str(len(str(i)))))
                     if cmd == "EXIT":
                          brodcast_to_all_clients(client, Encrypt(key, str(data + " left*")))
                     if "<" in last_received_messages and ">" in last_received_messages:
                       msg = last_received_messages
                       public_or_private = msg.split(": ")[1]
                       all_or_user = public_or_private.split("<")[1]
                       send_to = all_or_user.split(">")[0]
                       encrypted = all_or_user.split(">")[1]
                       print("Send to:", send_to)
                       if send_to == "all":
                          brodcast_to_all_clients_encrypted(client, incoming_buffer)
                       else:
                          user = send_to
                          print("starting the sending private message process")
                          for i in range(len(connected_users)):
                              if connected_users[i] == send_to:
                                  user_socket = connected_sockets[i]
                                  print(user_socket)
                          brodcast_only_to_one_user_encrypted(user_socket, incoming_buffer)
               #except:
                #   break



def send_Add_msg(joined_user):
    """
    :param: joined_user
    :return: nothing
    The function sends Add message to the client.
    """
    global client_list
    global List_Of_Chat_Messages
    msg = str("Add:" + joined_user + "*")
    if msg not in List_Of_Chat_Messages:
        List_Of_Chat_Messages.append(msg)
    for client in client_list:
        client.send(Encrypt(key, str(msg)))
        time.sleep(1)
        #client.send(Encrypt(key, str(len(msg))))


def add_to_client_list(client):
        """
        :param: client
        :return: the client username
        The function appends the username to the client list of the connected users.
        """
        global client_list
        if client not in client_list:
            client_list.append(client)
            return client
        else:
            return ""





def recv_messages_in_a_new_thread(server_socket):
        """
        :param: server_socket
        :return: nothing
        The function starts a thread on another function that receives messages from the connected clients.
        """
        global fernet
        global last_received_messages
        global client_list
        client_socket, client_adress = server_socket.accept()
        client = add_to_client_list(client_socket)
        print("Connected to " + str(client_adress))
        client.send(key)
        t = threading.Thread(target=receive_messages, args=(client,))
        t.start()
        print("started thread")


def brodcast_to_all_clients(senders_socket, msg):
    """
    :param: senders_socket
    :param: msg
    :return: The function gets a message and sends the message to all of the connected users except for the sender socket.
    """
    global fernet
    global client_list
    global last_received_messages
    for client in client_list:
        if client is not senders_socket:
            client.send(msg)
            time.sleep(1)
         #   client.send(Encrypt(key, str(len(msg))))



def brodcast_to_all_clients_encrypted(senders_socket, msg):
        """
        :param: senders_socket
        :param: msg
        :return: The function gets a message and sends the message to all of the connected users except for the sender socket.
        """
        global fernet
        global client_list
        global last_received_messages
        for client in client_list:
            if client is not senders_socket:
                client.send(msg)
                time.sleep(1)
          #      client.send(Encrypt(key, str(len(msg))))



def brodcast_only_to_one_user(user_socket, msg):
    """
    :param: user_socket
    :param: msg
    :return: The function gets a message and sends the message only to one user.
    """
    global client_list
    global user
    global last_received_messages
    personal_msg = False
    for client in client_list:
        if client is user_socket:
            if client == user:
                print("the user is sending the message to himself")
                personal_msg = True
    if personal_msg == False:
        client.send(msg)
        time.sleep(1)
        #client.send(Encrypt(key, str(len(msg))))


def brodcast_only_to_one_user_encrypted(user_socket, msg):
        """
        :param: user_socket
        :param: msg
        :return: The function gets a message and sends the message only to one user.
        """
        global client_list
        global user
        global last_received_messages
        personal_msg = False
        for client in client_list:
            if client is user_socket:
                if client == user:
                    print("the user is sending the message to himself")
                    personal_msg = True
        if personal_msg == False:
            client.send(msg)
            time.sleep(1)
            #client.send(Encrypt(key, str(len(msg))))



def main():
    """
    :param: nothing
    :return: nothing
    The main function enables many clients to connect to one server and to get
    permissions from him to sign up and to the chat.
    """
    print("Welcome to Chat Server!")
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('0.0.0.0', 6555))
    while True:
       server_socket.listen()
       print("Server is up and running")
       recv_messages_in_a_new_thread(server_socket)






main()


